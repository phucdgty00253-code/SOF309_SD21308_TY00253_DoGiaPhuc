# Lab 3 - CSDL, Entity, JdbcUtil, DAO

| Bài | File |
|---|---|
| 1 | `sql/Lab_3.sql` (SQL Server; script xóa database `polycoffee` cũ rồi tạo lại, kèm dữ liệu mẫu) |
| 2 | `src/com/polycoffee/entity/` |
| 3 | `src/com/polycoffee/util/JdbcUtil.java`, `dao/CategoryDAO.java` |
| 4 | `src/com/polycoffee/dao/` |

Cần driver `mssql-jdbc`. Cấu hình kết nối bằng `db.properties` trên classpath hoặc biến môi trường `DB_URL`, `DB_USER`, `DB_PASSWORD`.
