# Lab 4 - Tiện ích, Filter, đăng nhập, CRUD loại đồ uống

1. Chạy `Lab_3.sql` (trong thư mục lab3) trên SQL Server.
2. Chép `src/main/resources/db.properties.example` thành `db.properties`, điền mật khẩu.
3. `mvn clean package`, chép `target/polycoffee.war` vào `webapps/` của Tomcat 11.
4. Mở `http://localhost:8080/polycoffee/home`. Quản lý: `admin@polycoffee.vn`; nhân viên: `nhanvien@polycoffee.vn`; mật khẩu `123456`.

Project gồm cả mã Lab 3. Vài lớp hỗ trợ (`MailUtil`, `PasswordReset`, `DrinkService`) có mặt vì đăng nhập và trang chủ dùng chung service với lab sau.
Một số mục trên thanh menu thuộc lab sau nên mở trong project này sẽ báo 404.
